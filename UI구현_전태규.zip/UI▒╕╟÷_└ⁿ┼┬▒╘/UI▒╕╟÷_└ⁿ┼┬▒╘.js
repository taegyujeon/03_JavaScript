const numbers = document.querySelectorAll(".number");
const result = document.querySelector("#result");

for(let item of numbers){
    item.addEventListener("click", e => {
      result.textContent += e.target.textContent;
    }); 
}

document.querySelector("#resetBtn").addEventListener("click", e=>{
    result.textContent = "";
});

document.querySelector("#addBtn").addEventListener("click", () => {

    const li = document.createElement("li");
    li.innerText = result.innerText;
    recordNumber.append(li);
    result.innerText = "";

    const star = document.createElement("star");
    star.classList.add("iconstar");
    star.innerText = "☆";
    recordNumber.append(star);

    const del = document.createElement("del");
    del.classList.add("icondel");
    del.innerText = "x";
    recordNumber.append(del);

    star.addEventListener("click",e => {
        const count = document.querySelectorAll(".active").length;
        if(e.target.classList.contains("active")){
            e.target.classList.toggle("active");
        }
    });
});